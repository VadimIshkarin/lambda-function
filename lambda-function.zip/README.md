# Lambda function

## Description

A Lambda function (using Node.js/JavaScript) should take an image in an S3 bucket, resize it, and put the resized version of the image in the S3 bucket.

## Dependencies

"@aws-sdk/client-s3": "^3.276.0",
"jimp": "^0.22.5"
